package ar.com.telecom.shiva.base.jms.servicios;


public interface IJmsServicio {	
}
