package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import ar.com.telecom.shiva.base.dto.REG;
import ar.com.telecom.shiva.base.enumeradores.TipoResultadoEnum;

@SuppressWarnings("serial")
public class MicOperacionMasivaDatosRespuestaGeneralesEntrada extends REG {
	private TipoResultadoEnum resultadoConsulta;
	private String codigoError;
	private String descripcionError;

	/**
	 * @return the resultadoConsulta
	 */
	public TipoResultadoEnum getResultadoConsulta() {
		return resultadoConsulta;
	}
	/**
	 * @param resultadoConsulta the resultadoConsulta to set
	 */
	public void setResultadoConsulta(TipoResultadoEnum resultadoConsulta) {
		this.resultadoConsulta = resultadoConsulta;
	}
	/**
	 * @return the codigoError
	 */
	public String getCodigoError() {
		return codigoError;
	}
	/**
	 * @param codigoError the codigoError to set
	 */
	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}
	/**
	 * @return the descripcionError
	 */
	public String getDescripcionError() {
		return descripcionError;
	}
	/**
	 * @param descripcionError the descripcionError to set
	 */
	public void setDescripcionError(String descripcionError) {
		this.descripcionError = descripcionError;
	}
}
