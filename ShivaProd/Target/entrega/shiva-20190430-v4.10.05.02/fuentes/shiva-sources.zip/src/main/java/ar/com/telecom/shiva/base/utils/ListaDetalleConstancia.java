package ar.com.telecom.shiva.base.utils;

import java.math.BigDecimal;

public class ListaDetalleConstancia {

	private String banco;
	private String chequeNumero;
	private String diaVencimiento;
	private String mesVencimiento;
	private String anioVencimiento;
	private BigDecimal importe;
	private String numeroChequeReemplazado;
	private String constanciaAnterior;

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getChequeNumero() {
		return chequeNumero;
	}

	public void setChequeNumero(String chequeNumero) {
		this.chequeNumero = chequeNumero;
	}

	public String getDiaVencimiento() {
		return diaVencimiento;
	}

	public void setDiaVencimiento(String diaVencimiento) {
		this.diaVencimiento = diaVencimiento;
	}

	public String getMesVencimiento() {
		return mesVencimiento;
	}

	public void setMesVencimiento(String mesVencimiento) {
		this.mesVencimiento = mesVencimiento;
	}

	public String getAnioVencimiento() {
		return anioVencimiento;
	}

	public void setAnioVencimiento(String anioVencimiento) {
		this.anioVencimiento = anioVencimiento;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public String getNumeroChequeReemplazado() {
		return numeroChequeReemplazado;
	}

	public void setNumeroChequeReemplazado(String numeroChequeReemplazado) {
		this.numeroChequeReemplazado = numeroChequeReemplazado;
	}

	public String getConstanciaAnterior() {
		return constanciaAnterior;
	}

	public void setConstanciaAnterior(String constanciaAnterior) {
		this.constanciaAnterior = constanciaAnterior;
	}
}
