package ar.com.telecom.shiva.base.excepciones.otros;

import ar.com.telecom.shiva.base.excepciones.NegocioExcepcion;

public class ArchivoCotizacionesSapVacioExcepcion extends NegocioExcepcion {
	
	private static final long serialVersionUID = 1L;
	
	public ArchivoCotizacionesSapVacioExcepcion() {
		super();
	}
	
	public ArchivoCotizacionesSapVacioExcepcion(String mensaje) {
		super(mensaje);
	}
}
