package ar.com.telecom.shiva.base.jms.util.definicion;

public class CampoAEnviarJMS {
	
	protected Integer posicion;
	protected String nombreCampo;
	protected String nombreCampoAgrupador;
	protected String valorCampo;
	
	public CampoAEnviarJMS(String nombreCampo, String nombreCampoAgrupador, Integer pos, String valorCampo) {
		this.posicion = pos;
		this.nombreCampo=nombreCampo;
		this.nombreCampoAgrupador=nombreCampoAgrupador;
		this.valorCampo=valorCampo;
	}
	
	public String getNombreCampo() {
		return nombreCampo;
	}
	public void setNombreCampo(String nombreCampo) {
		this.nombreCampo = nombreCampo;
	}
	public String getValorCampo() {
		return valorCampo;
	}
	public void setValorCampo(String valorCampo) {
		this.valorCampo = valorCampo;
	}

	public String getNombreCampoAgrupador() {
		return nombreCampoAgrupador;
	}

	public void setNombreCampoAgrupador(String nombreCampoAgrupador) {
		this.nombreCampoAgrupador = nombreCampoAgrupador;
	}

	public Integer getPosicion() {
		return posicion;
	}

	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	
}
