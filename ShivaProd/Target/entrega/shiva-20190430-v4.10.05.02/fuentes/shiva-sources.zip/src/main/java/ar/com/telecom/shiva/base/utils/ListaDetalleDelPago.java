package ar.com.telecom.shiva.base.utils;

import java.math.BigDecimal;

public class ListaDetalleDelPago {

	private String dato1;
	private String dato2;
	private BigDecimal importe;

	public String getDato1() {
		return dato1;
	}

	public void setDato1(String dato1) {
		this.dato1 = dato1;
	}

	public String getDato2() {
		return dato2;
	}

	public void setDato2(String dato2) {
		this.dato2 = dato2;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

}
