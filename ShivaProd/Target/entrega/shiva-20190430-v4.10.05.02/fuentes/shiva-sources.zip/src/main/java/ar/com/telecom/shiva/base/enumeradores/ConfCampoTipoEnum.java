package ar.com.telecom.shiva.base.enumeradores;

/**
 * @author u578936 M.A.Uehara
 *
 */
public enum ConfCampoTipoEnum {

	CONF_OTROS_DEBITOS("sociedad");
	
	
	String descripcion;
	
	private ConfCampoTipoEnum(String descripcion) {
		this.descripcion = descripcion;
	}
}
