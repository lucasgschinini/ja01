package ar.com.telecom.shiva.base.dto;

import java.io.Serializable;

/**
 * DTO para la capa de presentacion (WEB) 
 */
@SuppressWarnings("serial")
public class SOA  extends Object implements Serializable {

	public SOA(){
	}
}
