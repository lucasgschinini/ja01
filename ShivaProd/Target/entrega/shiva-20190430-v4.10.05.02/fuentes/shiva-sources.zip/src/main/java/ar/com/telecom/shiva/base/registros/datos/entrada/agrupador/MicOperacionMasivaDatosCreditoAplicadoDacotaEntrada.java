package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import java.util.Date;

import ar.com.telecom.shiva.base.dto.REG;

@SuppressWarnings("serial")
public class MicOperacionMasivaDatosCreditoAplicadoDacotaEntrada extends REG {
	private Date fechaVencimientoMora;
	private String indicadorPeticionCorte;
	private String codigoTarifa;

	/**
	 * @return the fechaVencimientoMora
	 */
	public Date getFechaVencimientoMora() {
		return fechaVencimientoMora;
	}
	/**
	 * @param fechaVencimientoMora the fechaVencimientoMora to set
	 */
	public void setFechaVencimientoMora(Date fechaVencimientoMora) {
		this.fechaVencimientoMora = fechaVencimientoMora;
	}
	/**
	 * @return the indicadorPeticionCorte
	 */
	public String getIndicadorPeticionCorte() {
		return indicadorPeticionCorte;
	}
	/**
	 * @param indicadorPeticionCorte the indicadorPeticionCorte to set
	 */
	public void setIndicadorPeticionCorte(String indicadorPeticionCorte) {
		this.indicadorPeticionCorte = indicadorPeticionCorte;
	}
	/**
	 * @return the codigoTarifa
	 */
	public String getCodigoTarifa() {
		return codigoTarifa;
	}
	/**
	 * @param codigoTarifa the codigoTarifa to set
	 */
	public void setCodigoTarifa(String codigoTarifa) {
		this.codigoTarifa = codigoTarifa;
	}
}
