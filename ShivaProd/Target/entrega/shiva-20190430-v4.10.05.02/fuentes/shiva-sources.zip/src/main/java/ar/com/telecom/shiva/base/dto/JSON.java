package ar.com.telecom.shiva.base.dto;

public class JSON {

}