package ar.com.telecom.shiva.base.utils;

import java.math.BigDecimal;

public class ListaDetalleDelDeposito {

	private String banco;
	private Long chequeNumero;
	private BigDecimal importe;
	private String diaVencimiento;
	private String mesVencimiento;
	private String anioVencimiento;

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public Long getChequeNumero() {
		return chequeNumero;
	}

	public void setChequeNumero(Long chequeNumero) {
		this.chequeNumero = chequeNumero;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public String getDiaVencimiento() {
		return diaVencimiento;
	}

	public void setDiaVencimiento(String diaVencimiento) {
		this.diaVencimiento = diaVencimiento;
	}

	public String getMesVencimiento() {
		return mesVencimiento;
	}

	public void setMesVencimiento(String mesVencimiento) {
		this.mesVencimiento = mesVencimiento;
	}

	public String getAnioVencimiento() {
		return anioVencimiento;
	}

	public void setAnioVencimiento(String anioVencimiento) {
		this.anioVencimiento = anioVencimiento;
	}

}
