package ar.com.telecom.shiva.base.dto;


/**
 * Objeto SOA WebService 
 */
public class WS extends SOA {

	private static final long serialVersionUID = 4130001118020957462L;
	
	
}
