package ar.com.telecom.shiva.base.enumeradores;



public enum AlgoritmoMoraEnum {
	INTERES_LINEAL,
	CALCULO_LINEAL;
	
}
