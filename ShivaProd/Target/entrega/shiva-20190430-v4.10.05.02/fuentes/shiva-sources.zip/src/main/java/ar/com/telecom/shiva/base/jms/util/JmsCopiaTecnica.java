package ar.com.telecom.shiva.base.jms.util;

public class JmsCopiaTecnica {
	
	protected String msgLength;
	protected String codRetorno;
	protected String sqlCode;
	protected String sqlErrml;
	protected String sqlErrmc;
	protected String ultRegProc;
	protected String cantRegistros;
	
	public String toString() {
		String strRetorno = "[msgLength:"+String.valueOf(msgLength)+"],"
				+ "[codRetorno:"+String.valueOf(codRetorno)+"],"
				+ "[sqlCode:"+String.valueOf(sqlCode)+"],"
				+ "[sqlErrml:"+String.valueOf(sqlErrml)+"],"
				+ "[sqlErrmc:"+String.valueOf(sqlErrmc)+"],"
				+ "[ultRegProc:"+String.valueOf(ultRegProc)+"],"
				+ "[cantRegistros:" + String.valueOf(cantRegistros)+"]";
		
		return strRetorno;
	}
	
	/*********************************************************************
	 * Getters & Setters
	 *********************************************************************/
	
	public String getMsgLength() {
		return msgLength;
	}
	public void setMsgLength(String msgLength) {
		this.msgLength = msgLength;
	}
	public String getCodRetorno() {
		return codRetorno;
	}
	public void setCodRetorno(String codRetorno) {
		this.codRetorno = codRetorno;
	}
	public String getSqlCode() {
		return sqlCode;
	}
	public void setSqlCode(String sqlCode) {
		this.sqlCode = sqlCode;
	}
	public String getSqlErrml() {
		return sqlErrml;
	}
	public void setSqlErrml(String sqlErrml) {
		this.sqlErrml = sqlErrml;
	}
	public String getSqlErrmc() {
		return sqlErrmc;
	}
	public void setSqlErrmc(String sqlErrmc) {
		this.sqlErrmc = sqlErrmc;
	}
	public String getUltRegProc() {
		return ultRegProc;
	}
	public void setUltRegProc(String ultRegProc) {
		this.ultRegProc = ultRegProc;
	}
	public String getCantRegistros() {
		return cantRegistros;
	}
	public void setCantRegistros(String cantRegistros) {
		this.cantRegistros = cantRegistros;
	}

	
	
}
