package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import ar.com.telecom.shiva.base.dto.REG;
import ar.com.telecom.shiva.base.enumeradores.TipoArchivoOperacionMasivaEnum;
import ar.com.telecom.shiva.base.enumeradores.TipoRegistroEnum;

@SuppressWarnings("serial")
public class MicOperacionMasivaParametrosEntrada extends REG {
	private TipoRegistroEnum tipoRegistro = TipoRegistroEnum.D;
	private Long idOperacionMasiva;
	private TipoArchivoOperacionMasivaEnum tipoInvocacion;
	private Long idOperacion;
	private Long idTransaccion;

	public TipoRegistroEnum getTipoRegistro() {
		return tipoRegistro;
	}
	public void setTipoRegistro(TipoRegistroEnum tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}
	public Long getIdOperacionMasiva() {
		return idOperacionMasiva;
	}
	public void setIdOperacionMasiva(Long idOperacionMasiva) {
		this.idOperacionMasiva = idOperacionMasiva;
	}
	public TipoArchivoOperacionMasivaEnum getTipoInvocacion() {
		return tipoInvocacion;
	}
	public void setTipoInvocacion(TipoArchivoOperacionMasivaEnum tipoInvocacion) {
		this.tipoInvocacion = tipoInvocacion;
	}
	public Long getIdOperacion() {
		return idOperacion;
	}
	public void setIdOperacion(Long idOperacion) {
		this.idOperacion = idOperacion;
	}
	public Long getIdTransaccion() {
		return idTransaccion;
	}
	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
}
