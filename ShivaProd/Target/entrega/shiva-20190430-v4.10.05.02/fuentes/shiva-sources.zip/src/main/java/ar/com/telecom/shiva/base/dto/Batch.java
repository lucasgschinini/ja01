package ar.com.telecom.shiva.base.dto;

import java.io.Serializable;

public class Batch  extends Object implements Serializable {

	private static final long serialVersionUID = 4130001118020957462L;
	
	private Serializable id;
	
	public Batch(){
	}

	public Batch(Serializable key){
		this.setId(key);
	}
	
		
	/*********************************************************************************
	 * Setters & Getters
	 ********************************************************************************/
	public Serializable getId() {
		return id;
	}

	public void setId(Serializable id) {
		this.id = id;
	}
	
}
