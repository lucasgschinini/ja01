package ar.com.telecom.shiva.base.enumeradores;

public enum MensajeEstadoEnum {
	EN_PROCESO,
	PENDIENTE,
	ENVIADO,
	RECIBIDO,
	REC_ERROR,
	NORECIBIDO,
	COMPLETADO,
	CANCELADO
	
}
