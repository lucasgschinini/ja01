
package ar.com.telecom.shiva.base.ws.cliente.datos;


public class IdDocumentoMic {

    protected String numeroReferenciaMic;

	public String getNumeroReferenciaMic() {
		return numeroReferenciaMic;
	}

	public void setNumeroReferenciaMic(String numeroReferenciaMic) {
		this.numeroReferenciaMic = numeroReferenciaMic;
	}

}
