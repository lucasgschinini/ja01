package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import java.math.BigDecimal;

import ar.com.telecom.shiva.base.dto.REG;

public class DetalleAplicacionManualRta extends REG{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String IdOperacionExterna;
	private String sistema;
	private String referente;
	private BigDecimal importeAplicado;
	private String importeAplicadoString;
	
	public String getImporteAplicadoString() {
		return importeAplicadoString;
	}
	public void setImporteAplicadoString(String importeAplicadoString) {
		this.importeAplicadoString = importeAplicadoString;
	}
	/**
	 * @return the idOperacionExterna
	 */
	public String getIdOperacionExterna() {
		return IdOperacionExterna;
	}
	/**
	 * @param idOperacionExterna the idOperacionExterna to set
	 */
	public void setIdOperacionExterna(String idOperacionExterna) {
		IdOperacionExterna = idOperacionExterna;
	}
	/**
	 * @return the sistema
	 */
	public String getSistema() {
		return sistema;
	}
	/**
	 * @param sistema the sistema to set
	 */
	public void setSistema(String sistema) {
		this.sistema = sistema;
	}
	/**
	 * @return the referente
	 */
	public String getReferente() {
		return referente;
	}
	/**
	 * @param referente the referente to set
	 */
	public void setReferente(String referente) {
		this.referente = referente;
	}
	/**
	 * @return the importeAplicado
	 */
	public BigDecimal getImporteAplicado() {
		return importeAplicado;
	}
	/**
	 * @param importeAplicado the importeAplicado to set
	 */
	public void setImporteAplicado(BigDecimal importeAplicado) {
		this.importeAplicado = importeAplicado;
	} 
}
