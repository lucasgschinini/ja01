package ar.com.telecom.shiva.base.jms.datos.salida.agrupador;



public class MicInformacionRemanente {

	private Integer		codigoTipoRemanente;
	private String		descripcionTipoRemanente;
	
	public Integer getCodigoTipoRemanente() {
		return codigoTipoRemanente;
	}
	public void setCodigoTipoRemanente(Integer codigoTipoRemanente) {
		this.codigoTipoRemanente = codigoTipoRemanente;
	}
	public String getDescripcionTipoRemanente() {
		return descripcionTipoRemanente;
	}
	public void setDescripcionTipoRemanente(String descripcionTipoRemanente) {
		this.descripcionTipoRemanente = descripcionTipoRemanente;
	}
}
