package ar.com.telecom.shiva.base.comparador;

import java.io.Serializable;
import java.util.Comparator;

import ar.com.telecom.shiva.negocio.simulacionCoherencia.ShvCobEdDocumentoCapWrapper;
/**
 * 
 * @author u578936 Max Uehara
 */
public class ComparatorShvCobEdDocumentoCapWrapper implements Comparator<ShvCobEdDocumentoCapWrapper>, Serializable {
	private static final long serialVersionUID = 20170102L;

	@Override
	public int compare(ShvCobEdDocumentoCapWrapper o1, ShvCobEdDocumentoCapWrapper o2) {
		return o1.getIdPantalla().compareTo(o2.getIdPantalla());
	}
}
