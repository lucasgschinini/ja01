package ar.com.telecom.shiva.base.ws.cliente.datos.entrada;

import ar.com.telecom.shiva.base.dto.WS;

@SuppressWarnings("serial")
public class EntradaWS extends WS {
		
}
