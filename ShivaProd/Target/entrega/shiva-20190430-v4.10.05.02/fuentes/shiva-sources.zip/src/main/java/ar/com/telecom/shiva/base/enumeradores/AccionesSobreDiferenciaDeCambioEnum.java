package ar.com.telecom.shiva.base.enumeradores;



public enum AccionesSobreDiferenciaDeCambioEnum {
	GA("Generar y aplicar"),
	NG("No generar"),
	NA("No aplica");

	private AccionesSobreDiferenciaDeCambioEnum(String descripcion) {
		this.descripcion = descripcion;
	}
	
	String descripcion;

	public String getDescripcion() {
		return descripcion;
	}	
	
}


