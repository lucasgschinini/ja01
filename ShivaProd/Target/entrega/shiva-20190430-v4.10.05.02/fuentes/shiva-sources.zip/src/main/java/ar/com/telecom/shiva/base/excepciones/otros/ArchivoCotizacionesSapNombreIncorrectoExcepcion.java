package ar.com.telecom.shiva.base.excepciones.otros;

import ar.com.telecom.shiva.base.excepciones.NegocioExcepcion;

public class ArchivoCotizacionesSapNombreIncorrectoExcepcion  extends NegocioExcepcion {
	
	private static final long serialVersionUID = 1L;
	
	public ArchivoCotizacionesSapNombreIncorrectoExcepcion() {
		super();
	}
	
	public ArchivoCotizacionesSapNombreIncorrectoExcepcion(String mensaje) {
		super(mensaje);
	}

}
