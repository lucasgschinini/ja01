package ar.com.telecom.shiva.base.utils.configuracion;


public class ConfiguracionShiva {
	
	public void init()
    {
        //Security.addProvider(new BouncyCastleProvider());
    }
}