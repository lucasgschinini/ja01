package ar.com.telecom.shiva.base.constantes;

public class ConstantesRecepcionNovedadesSAP {

	
	public static final String ERR_WS_RECEP_NOV_DATOS_FALTANTES = "2001";
	
	public static final String ERR_WS_RECEP_NOV_DATOS_ERRONEOS = "2011";
	
	public static final String ERR_WS_RECEP_NOV_ERROR_INESPERADO= "5001";
	
	public static final String NOK_WS_RECEP_NOV_DOC_INEXISTENTE= "3001";
	
	public static final String ERROR_WS_RECEP_NOV_DATOS_FALTANTES = "2001";
	
}
