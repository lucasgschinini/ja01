package ar.com.telecom.shiva.base.ws.cliente.datos.entrada;

import ar.com.telecom.shiva.base.enumeradores.SiNoEnum;
import ar.com.telecom.shiva.base.ws.cliente.datos.entrada.agrupador.deimos.Transaccion;
/**
 * @author u573005
 * sprint5
 */
@SuppressWarnings("serial")
public class EntradaDeimosApropiacionWS extends EntradaWS {
	
	protected Long idOperacionShiva;
	protected String usuarioCobrador;
	protected Transaccion transaccion;
	protected SiNoEnum modoOperacion;
	
	/*************************************************
	 * Getters & Setters
	 *************************************************/
	public String getUsuarioCobrador() {
		return usuarioCobrador;
	}
	public void setUsuarioCobrador(String usuarioCobrador) {
		this.usuarioCobrador = usuarioCobrador;
	}
	public Transaccion getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(Transaccion transaccion) {
		this.transaccion = transaccion;
	}
	public SiNoEnum getModoOperacion() {
		return modoOperacion;
	}
	public void setModoOperacion(SiNoEnum modoOperacion) {
		this.modoOperacion = modoOperacion;
	}
	public Long getIdOperacionShiva() {
		return idOperacionShiva;
	}
	public void setIdOperacionShiva(Long idOperacionShiva) {
		this.idOperacionShiva = idOperacionShiva;
	}
}