package ar.com.telecom.shiva.base.enumeradores;

public enum EstadoConsultaSaldoChequeRechazadoEnum {

	EN_PROCESO("En proceso"),
	PENDIENTE("Pendiente"),
	FINALIZADO_OK("Validado Ok"),
	FINALIZADO_ERROR("Validado Error");
	
	String descripcion;
	
	private EstadoConsultaSaldoChequeRechazadoEnum(String descripcion) {
	    this.descripcion = descripcion;
	}
	
	public String descripcion() {
	    return this.descripcion;
	}
}
