package ar.com.telecom.shiva.base.dto;


/**
 * Objeto SOA REG
 */
public class REG extends SOA {

	private static final long serialVersionUID = 4130001118020957462L;
	
	public REG(){
	}
}
