package ar.com.telecom.shiva.base.jms.datos.entrada.agrupador;


public class MicInformacionConvenios {

	protected Integer 		secuencialDeCuenta;
	protected Integer 		secuencialDeConvenio;
	protected Integer 		numeroDeCuota;
	
	public Integer getSecuencialDeCuenta() {
		return secuencialDeCuenta;
	}
	public void setSecuencialDeCuenta(Integer secuencialDeCuenta) {
		this.secuencialDeCuenta = secuencialDeCuenta;
	}
	public Integer getSecuencialDeConvenio() {
		return secuencialDeConvenio;
	}
	public void setSecuencialDeConvenio(Integer secuencialDeConvenio) {
		this.secuencialDeConvenio = secuencialDeConvenio;
	}
	public Integer getNumeroDeCuota() {
		return numeroDeCuota;
	}
	public void setNumeroDeCuota(Integer numeroDeCuota) {
		this.numeroDeCuota = numeroDeCuota;
	}
}
