package ar.com.telecom.shiva.base.registros.datos.entrada.enumeradores;

public enum MicOperacionMasivacAgrupacionCamposEntradaEnum {

	CABECERA,
	PARAMETRO_GENERALES,
	COBRANZA_GENERALES,
	COBRANZA_APROPIACION_DEUDA,
	COBRANZA_GENERACION_CARGO,
	CLIENTE_DEBITO_IMPUTADO,
	DEBITO_IMPUTAD_GRAL,
	DEBITO_TAGETIK,
	DEBITO_DAKOTA,
	DEBITO_SALDO_TERCEROS,
	
	CREDITO_TAGETIK,
	CREDITO_DAKOTA,
	ACUERDO_GNERALES,
	ACUERDO_CLIENTE,
	RESPUESTA_DEBITO,
	RESPUESTA_CREDITO,
	RESPUESTA_REINTEGRO,
	PIE;
	
	

	
	private MicOperacionMasivacAgrupacionCamposEntradaEnum() {
	}
	
}
