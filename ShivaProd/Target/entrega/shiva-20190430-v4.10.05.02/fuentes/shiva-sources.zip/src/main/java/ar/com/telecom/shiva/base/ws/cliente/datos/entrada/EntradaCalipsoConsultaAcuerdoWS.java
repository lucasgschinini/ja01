package ar.com.telecom.shiva.base.ws.cliente.datos.entrada;

import java.math.BigInteger;



@SuppressWarnings("serial")
public class EntradaCalipsoConsultaAcuerdoWS extends EntradaWS {
	
	protected BigInteger acuerdoFacturacion;

	/*******************************************************************
	 * Getters & Setters
	 ******************************************************************/
	public BigInteger getAcuerdoFacturacion() {
		return acuerdoFacturacion;
	}

	public void setAcuerdoFacturacion(BigInteger acuerdoFacturacion) {
		this.acuerdoFacturacion = acuerdoFacturacion;
	}
}