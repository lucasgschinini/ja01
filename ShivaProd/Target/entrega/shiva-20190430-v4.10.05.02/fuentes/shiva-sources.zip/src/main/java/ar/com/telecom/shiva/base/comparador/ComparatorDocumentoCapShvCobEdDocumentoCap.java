package ar.com.telecom.shiva.base.comparador;

import java.util.Comparator;

import ar.com.telecom.shiva.persistencia.modelo.ShvCobEdDocumentoCap;

public class ComparatorDocumentoCapShvCobEdDocumentoCap implements Comparator<ShvCobEdDocumentoCap> {

	@Override
	public int compare(ShvCobEdDocumentoCap arg0, ShvCobEdDocumentoCap arg1) {
		return arg0.getIdCapReferencia().compareTo(arg1.getIdCapReferencia());
		
		
	}
}
