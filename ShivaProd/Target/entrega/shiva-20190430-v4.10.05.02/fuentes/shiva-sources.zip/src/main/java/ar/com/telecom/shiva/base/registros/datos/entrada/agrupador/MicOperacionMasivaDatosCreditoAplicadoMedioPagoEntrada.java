package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import ar.com.telecom.shiva.base.dto.REG;
import ar.com.telecom.shiva.base.enumeradores.TipoComprobanteEnum;

@SuppressWarnings("serial")
public class MicOperacionMasivaDatosCreditoAplicadoMedioPagoEntrada extends REG {
	private Long cuenta;
	private TipoComprobanteEnum tipoCredito;

	/**
	 * @return the cuenta
	 */
	public Long getCuenta() {
		return cuenta;
	}
	/**
	 * @param cuenta the cuenta to set
	 */
	public void setCuenta(Long cuenta) {
		this.cuenta = cuenta;
	}
	/**
	 * @return the tipoCredito
	 */
	public TipoComprobanteEnum getTipoCredito() {
		return tipoCredito;
	}
	/**
	 * @param tipoCredito the tipoCredito to set
	 */
	public void setTipoCredito(TipoComprobanteEnum tipoCredito) {
		this.tipoCredito = tipoCredito;
	}
}
