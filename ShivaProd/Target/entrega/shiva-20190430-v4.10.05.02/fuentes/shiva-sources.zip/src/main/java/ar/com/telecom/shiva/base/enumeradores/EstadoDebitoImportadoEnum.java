package ar.com.telecom.shiva.base.enumeradores;



public enum EstadoDebitoImportadoEnum {
	
	PENDIENTE("Pendiente"),
	EN_PROCESO("En proceso"),
	VALIDACION_OK("Validado Ok"),
	VALIDACION_ERROR("Validado Error");
	
	String descripcion;
	
	private EstadoDebitoImportadoEnum(String descripcion) {
	    this.descripcion = descripcion;
	}
	
	public String descripcion() {
	    return this.descripcion;
	}
}
