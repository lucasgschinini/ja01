package ar.com.telecom.shiva.base.registros.datos.salida.agrupador;

import java.util.Date;

import ar.com.telecom.shiva.base.dto.REG;
import ar.com.telecom.shiva.base.enumeradores.TipoReintegroEnum;

@SuppressWarnings("serial")
public class MicOperacionMasivaReintegroSalida extends REG {
	
	private Long tramiteReintegro;
	private Date fechaAltaTramiteReintegro;
	private TipoReintegroEnum tipoReintegro;
	
	public Long getTramiteReintegro() {
		return tramiteReintegro;
	}
	public void setTramiteReintegro(Long tramiteReintegro) {
		this.tramiteReintegro = tramiteReintegro;
	}
	public Date getFechaAltaTramiteReintegro() {
		return fechaAltaTramiteReintegro;
	}
	public void setFechaAltaTramiteReintegro(Date fechaAltaTramiteReintegro) {
		this.fechaAltaTramiteReintegro = fechaAltaTramiteReintegro;
	}
	public TipoReintegroEnum getTipoReintegro() {
		return tipoReintegro;
	}
	public void setTipoReintegro(TipoReintegroEnum tipoReintegro) {
		this.tipoReintegro = tipoReintegro;
	}
}
