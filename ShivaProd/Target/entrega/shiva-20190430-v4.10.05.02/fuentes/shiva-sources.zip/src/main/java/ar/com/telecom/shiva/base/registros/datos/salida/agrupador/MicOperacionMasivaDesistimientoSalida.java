package ar.com.telecom.shiva.base.registros.datos.salida.agrupador;

import java.util.Date;

import ar.com.telecom.shiva.base.dto.REG;

@SuppressWarnings("serial")
public class MicOperacionMasivaDesistimientoSalida extends REG {
	
	private String numeroActaDesistimiento;
	private Date fechaFirmaActaDesistimiento;
	
	public String getNumeroActaDesistimiento() {
		return numeroActaDesistimiento;
	}
	public void setNumeroActaDesistimiento(String numeroActaDesistimiento) {
		this.numeroActaDesistimiento = numeroActaDesistimiento;
	}
	public Date getFechaFirmaActaDesistimiento() {
		return fechaFirmaActaDesistimiento;
	}
	public void setFechaFirmaActaDesistimiento(Date fechaFirmaActaDesistimiento) {
		this.fechaFirmaActaDesistimiento = fechaFirmaActaDesistimiento;
	}
}
