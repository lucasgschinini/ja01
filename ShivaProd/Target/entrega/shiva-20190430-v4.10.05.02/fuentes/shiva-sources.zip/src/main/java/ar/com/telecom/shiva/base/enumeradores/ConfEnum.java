package ar.com.telecom.shiva.base.enumeradores;

/**
 * @author u578936 M.A.Uehara
 *
 */
public enum ConfEnum {

}
