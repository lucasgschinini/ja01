package ar.com.telecom.shiva.base.excepciones.otros;

import ar.com.telecom.shiva.base.excepciones.Excepcion;

public class ValidacionUnicidadLegajoChequeRechazadoExcepcion extends Excepcion {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	public ValidacionUnicidadLegajoChequeRechazadoExcepcion() {
		super();
	}

	/**
	 * 
	 * @param message
	 */
	public ValidacionUnicidadLegajoChequeRechazadoExcepcion(String message) {
		super(message);
	}

	/**
	 * 
	 * @param cause
	 */
	public ValidacionUnicidadLegajoChequeRechazadoExcepcion(Throwable cause) {
		super(cause);
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public ValidacionUnicidadLegajoChequeRechazadoExcepcion(String message, Throwable cause) {
		super(message, cause);
	}
	
	
}
