package ar.com.telecom.shiva.base.excepciones.otros;

import ar.com.telecom.shiva.base.excepciones.NegocioExcepcion;


/**
 * Excepcion del webservice
 *
 */
public class LdapExcepcion extends NegocioExcepcion {

	private static final long serialVersionUID = 1L;

	public LdapExcepcion() {
		super();
	}

	public LdapExcepcion(String message) {
		super(message);
	}

	public LdapExcepcion(Throwable cause) {
		super(cause);
	}

	public LdapExcepcion(String message, Throwable cause) {
		super(message, cause);
	}
}
