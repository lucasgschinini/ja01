package ar.com.telecom.shiva.base.registros.util.definicion;

import java.util.Comparator;

public class CampoCompPorOrden implements
		Comparator<Campo> {

	public int compare(Campo o1, Campo o2) {
		return Integer.valueOf(o1.getOrden())
				.compareTo(Integer.valueOf(o2.getOrden()));
	}
}
