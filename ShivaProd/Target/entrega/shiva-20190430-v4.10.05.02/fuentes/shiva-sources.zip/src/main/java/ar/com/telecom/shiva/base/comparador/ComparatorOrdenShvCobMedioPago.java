/**
 * 
 */
package ar.com.telecom.shiva.base.comparador;

import java.util.Comparator;

import ar.com.telecom.shiva.persistencia.modelo.ShvCobMedioPago;

/**
 * @author u573005, fabio.giaquinta.ruiz, sprint 7
 * 
 */
public class ComparatorOrdenShvCobMedioPago implements Comparator<ShvCobMedioPago> {

	@Override
	public int compare(ShvCobMedioPago o1, ShvCobMedioPago o2) {
		return o1.getIdMedioPago().compareTo(o2.getIdMedioPago());
	}

}
