package ar.com.telecom.shiva.base.excepciones.otros;

import ar.com.telecom.shiva.base.excepciones.NegocioExcepcion;

public class MailExcepcion extends NegocioExcepcion {
	
	private static final long serialVersionUID = 1L;
	
	public MailExcepcion(String message) {
		super(message);
	}
	
	public MailExcepcion(String message, Throwable cause) {
		super(message, cause);
	}
	
	
}
