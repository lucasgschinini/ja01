/**
 * 
 */
package ar.com.telecom.shiva.base.ws.cliente;

/**
 * @author u564030
 *
 */
public abstract class SapConsultasWS {
	
	// Variables que se utilizan como constantes en las llamadas a los servicios de SAP
	
	protected static final String SAP_WS_CODIGO_SOCIEDAD_TELECOM_ARGENTINA = "M650";
	protected static final String SAP_WS_CODIGO_SOCIEDAD_TELECOM_ARGENTINA_S4 = "A001";

	protected static final String SAP_WS_CAMPO_SIGN_VALOR_INCLUIR = "I";
	
	protected static final String SAP_WS_CAMPO_OPTION_VALOR_IGUAL = "EQ";
	protected static final String SAP_WS_CAMPO_OPTION_VALOR_MENOR_O_IGUAL = "LE";
	protected static final String SAP_WS_CAMPO_OPTION_VALOR_MAYOR_O_IGUAL = "GE";
	protected static final String SAP_WS_CAMPO_OPTION_VALOR_RANGO = "BT";
}
