package ar.com.telecom.shiva.base.registros.datos.entrada.agrupador;

import java.util.Date;

import ar.com.telecom.shiva.base.dto.REG;

@SuppressWarnings("serial")
public class MicOperacionMasivaDatosCobranzasGralesEntrada extends REG {

	Long idCobranza;
	Date fechaValorCobranza;
	/**
	 * @return the idCobranza
	 */
	public Long getIdCobranza() {
		return idCobranza;
	}
	/**
	 * @param idCobranza the idCobranza to set
	 */
	public void setIdCobranza(Long idCobranza) {
		this.idCobranza = idCobranza;
	}
	/**
	 * @return the fechaValorCobranza
	 */
	public Date getFechaValorCobranza() {
		return fechaValorCobranza;
	}
	/**
	 * @param fechaValorCobranza the fechaValorCobranza to set
	 */
	public void setFechaValorCobranza(Date fechaValorCobranza) {
		this.fechaValorCobranza = fechaValorCobranza;
	}
}
