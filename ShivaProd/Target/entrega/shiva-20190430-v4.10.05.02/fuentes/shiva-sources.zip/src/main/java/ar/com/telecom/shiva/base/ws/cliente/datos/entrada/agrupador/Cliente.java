package ar.com.telecom.shiva.base.ws.cliente.datos.entrada.agrupador;

import java.math.BigInteger;

import ar.com.telecom.shiva.base.ws.cliente.datos.IdDocumento;

public class Cliente {
	
	protected BigInteger idClienteLegado;
	protected IdDocumento idDocumento;
	
	public BigInteger getIdClienteLegado() {
		return idClienteLegado;
	}

	public void setIdClienteLegado(BigInteger idClienteLegado) {
		this.idClienteLegado = idClienteLegado;
	}

	public IdDocumento getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(IdDocumento idDocumento) {
		this.idDocumento = idDocumento;
	}

	
	
}
