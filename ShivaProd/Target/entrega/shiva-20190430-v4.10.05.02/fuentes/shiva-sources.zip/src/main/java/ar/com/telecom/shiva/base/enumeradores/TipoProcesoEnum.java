package ar.com.telecom.shiva.base.enumeradores;

public enum TipoProcesoEnum {

	COBRO,
	DESCOBRO;
}
