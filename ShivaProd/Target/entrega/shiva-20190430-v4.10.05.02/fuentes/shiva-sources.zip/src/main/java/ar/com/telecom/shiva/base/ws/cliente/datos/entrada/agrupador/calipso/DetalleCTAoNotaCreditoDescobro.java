package ar.com.telecom.shiva.base.ws.cliente.datos.entrada.agrupador.calipso;

import java.math.BigInteger;

public class DetalleCTAoNotaCreditoDescobro {
	
	protected BigInteger idCobranza;
	
	public BigInteger getIdCobranza() {
		return idCobranza;
	}

	public void setIdCobranza(BigInteger idCobranza) {
		this.idCobranza = idCobranza;
	}

}
